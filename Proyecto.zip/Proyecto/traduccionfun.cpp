void impresion(string mensaje, int informacion){
    printf("%s %d",mensaje.c_str(),informacion);
}
int llenarLista(int longitud){
    int Contenedor[longitud];
    for(int i=0; i<longitud; i++){
       int elemento=0;
       printf("Introduce un numero: ");
       scanf("%d",&elemento);
       Contenedor[i] = elemento;

    }
    return *Contenedor;
}
int sumatoria(int Lista[]){
    int suma = 0;
    for(int x=0; x<sizeof(Lista); x++){
       suma = suma + Lista[x];

    }
        return suma;
}
int calcularProducto(int Lista[]){
    int vActual = Lista[0];
    for(int x=1; x<sizeof(Lista); x++){
       vActual = Lista[x] * vActual;

    }
        return vActual;
}