#include <iostream>
#include <cstring>
#include <cmath>
#include <vector>
#include <stdio.h>
using namespace std;
int main()
{
    printf("Bienvenid(o a compiladores");
    int Datos=0;
    printf("Datos a introducir: ");
    scanf("%d",&Datos);
    impresion("El usuario introducira %d ",Datos);
    int tam=Datos;
    int datos[tam];
    datos[tam]=llenarLista(Datos);
    int Suma=0;
    Suma = sumatoria(datos);
    impresion("La sumatoria de los numeros es:  %d",Suma);
    int Producto=0;
    Producto = calcularProducto(datos);
}